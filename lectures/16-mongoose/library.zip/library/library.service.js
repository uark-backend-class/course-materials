const mongodb = require('./mongodb.utils');
const Author = require('./models/author.model');
const Book = require('./models/book.model');

module.exports = {
  fetchAllBooks,
  fetchAllAuthors,
  fetchAuthorsByFirstName,
  fetchAuthorsByLastName,
  fetchBookByTitle,
  saveBook,
  updateBook,
  saveAuthor,
  updateAuthor
}

function fetchAllBooks() {
  return Book.find({}).populate('author').exec();
}

function fetchAllAuthors() {
  return Author.find({}).populate('books').exec();
}

function fetchAuthorsByFirstName(firstname) {
  return Author.find({ firstname: firstname }).populate('books').exec();
}

function fetchAuthorsByLastName(lastname) {
  return Author.find({ lastname: lastname }).populate('books').exec();
}

function fetchBookByTitle(title) {
  return Book.find({ title: title }).populate('author').exec().then((searchResult) => {
    var bookToReturn = {};
    if (searchResult && searchResult.length > 0) {
      var bookFound = searchResult[0];
      bookToReturn = {
        title: bookFound.title,
        author: {
          firstname: bookFound.author.firstname,
          lastname: bookFound.author.lastname
        }
      };
    }

    return bookToReturn;
  });
}

function saveBook(bookToSave) {
  let authorInfo;
  let bookInfo;

  return Author.find({ firstname: bookToSave.author.firstname, lastname: bookToSave.author.lastname }).exec().then((authorSearchResult) => {
    if (authorSearchResult && authorSearchResult.length > 0) {
      return authorSearchResult[0];
    } else {
      var author = new Author({
        firstname: bookToSave.author.firstname,
        lastname: bookToSave.author.lastname
      });

      return author.save();
    }
  }).then((author) => {
    authorInfo = author;

    var book = new Book({
      title: bookToSave.title,
      author: authorInfo._id
    });

    return book.save();
  }).then((bookSaved) => {
    bookInfo = bookSaved;

    authorInfo.books.push(bookInfo._id);
    return authorInfo.save();
  }).then((updatedAuthorInfo) => {
    const infoToReturn = {
      author: updatedAuthorInfo,
      book: bookInfo
    };

    return infoToReturn;
  });
}

function updateBook(bookToUpdate) {
  return Book.findById(bookToUpdate.id).then((bookFetched) => {
    if (bookToUpdate.title) {
      bookFetched.title = bookToUpdate.title;
    }

    if (bookToUpdate.author) {
      bookFetched.author = bookToUpdate.author;
    }

    return bookFetched.save();
  });
}

function saveAuthor(authorToSave) {
  var authorInfo;
  var bookInfo;

  var author = new Author({
    firstname: authorToSave.firstname,
    lastname: authorToSave.lastname
  });

  return author.save().then((authorSaved) => {
    authorInfo = authorSaved;

    if (authorToSave.books) {
      const addBooks = [];

      authorToSave.books.forEach((book) => {
        const bookToSave = {
          "title": book,
          "author": {
            "firstname": authorInfo.firstname,
            "lastname": authorInfo.lastname
          }
        };

        addBooks.push(saveBook(bookToSave));
      });

      return Promise.all(addBooks);
    } else {
      return Promise.resolve(authorInfo);
    }
  }).then(() => {
    return Author.find({ firstname: authorInfo.firstname, lastname: authorInfo.lastname }).populate('books').exec();
  });
}

function updateAuthor(authorToUpdate) {
  return Author.findById(authorToUpdate.id).then((authorFetched) => {
    if (authorToUpdate.firstname) {
      authorFetched.firstname = authorToUpdate.firstname;
    }

    if (authorToUpdate.lastname) {
      authorFetched.lastname = authorToUpdate.lastname;
    }

    return authorFetched.save();
  });
}
