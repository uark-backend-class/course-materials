const express = require('express');
const bodyParser = require('body-parser');
const mongodb = require('./mongodb.utils');
const libraryService = require('./library.service');

const app = express();
const jsonParser = bodyParser.json();

const PORT = process.env.PORT || 8080;

mongodb.createEventListeners();
mongodb.connect();

app.get('/', (req, res) => {
  res.status(200).send('Healthcheck!');
});

app.get('/books', (req, res) => {
  libraryService.fetchAllBooks().then((booksFetched) => {
    res.status(200).send(booksFetched);
  }).catch(function (error) {
    res.status(500).send(error);
  });
});

app.get('/book/:title', (req, res) => {
  var bookTitle = req.params.title;
  libraryService.fetchBookByTitle(bookTitle).then((bookFetched) => {
    res.status(200).send(bookFetched);
  }).catch(function (error) {
    res.status(500).send(err);
  });
});

app.post('/book', jsonParser, (req, res) => {
  var bookData = req.body.book;

  libraryService.saveBook(bookData).then((bookSaved) => {
    res.status(200).send(bookSaved);
  }).catch((error) => {
    res.status(500).send(err);
  });
});

app.put('/book', jsonParser, (req, res) => {
  var bookData = req.body.book;

  libraryService.updateBook(bookData).then((bookUpdated) => {
    res.status(200).send(bookUpdated);
  }).catch((error) => {
    res.status(500).send(error);
  });
});

app.get('/authors', (req, res) => {
  libraryService.fetchAllAuthors().then((authorsFetched) => {
    res.status(200).send(authorsFetched);
  }).catch((error) => {
    res.status(500).send(error);
  });
});

app.get('/author', (req, res) => {
  const firstname = req.query.firstname;
  const lastname = req.query.lastname;

  if (firstname) {
    libraryService.fetchAuthorsByFirstName(firstname).then((authorsFetched) => {
      res.status(200).send(authorsFetched);
    }).catch(function (error) {
      res.status(500).send(error);
    });
  } else {
    libraryService.fetchAuthorsByLastName(lastname).then((authorsFetched) => {
      res.status(200).send(authorsFetched);
    }).catch(function (error) {
      res.status(500).send(error);
    });
  }
});

app.post('/author', jsonParser, (req, res) => {
  var authorData = req.body.author;

  libraryService.saveAuthor(authorData).then((authorSaved) => {
    res.status(200).send(authorSaved);
  }).catch(function (error) {
    res.status(500).send(err);
  });
});

app.put('/author', jsonParser, (req, res) => {
  var authorData = req.body.author;

  libraryService.updateAuthor(authorData).then((authorUpdated) => {
    res.status(200).send(authorUpdated);
  }).catch((error) => {
    res.status(500).send(error);
  });
});

app.listen(PORT, () => {
  console.log(`Listening on port ${PORT}`);
});
