module.exports = [
  {
    id: 'c086a982-2a5c-49a8-ab04-36b052e695d9',
    username: 'aturing',
    password: 'machineorhuman',
    firstName: 'Alan',
    lastName: 'Turing',
    created: '1912-06-23'
  },
  {
    id: '6ab3bc82-bd43-404d-904b-735e9a5bd2c0',
    username: 'aeinstein',
    password: 'emc2',
    firstName: 'Albert',
    lastName: 'Einstein',
    created: '1879-03-14'
  },
  {
    id: '109156be-c4fb-41ea-b1b4-efe1671c5836',
    username: 'alovelace',
    password: 'computerscience',
    firstName: 'Ada',
    lastName: 'Lovelace',
    created: '1815-12-10'
  },
  {
    id: '01cf7d16-906c-4fc8-9a39-e572f9ba710d',
    username: 'cgauss',
    password: 'mathisrad',
    firstName: 'Carl',
    lastName: 'Gauss',
    created: '1777-04-30'
  },
  {
    id: '153b5d77-a27e-452c-8d50-6c40a1a0e2f7',
    username: 'inewton',
    password: 'gravityitsthelaw',
    firstName: 'Isaac',
    lastName: 'Newton',
    created: '1643-01-04'
  }
];
